

  <!-- content start -->
  <div class="admin-content">

    <div class="am-cf am-padding">
      <div class="am-fl am-cf"><strong class="am-text-primary am-text-lg">首页</strong> / <small>一些常用模块</small></div>
    </div>

    <ul class="am-avg-sm-1 am-avg-md-4 am-margin am-padding am-text-center admin-content-list ">
      欢迎管理员:&nbsp;&nbsp; <b><?=$_SESSION['users']['userName'];?></b>,进入城实安全后台管理！
    </ul>

  
  </div>
  <!-- content end -->

