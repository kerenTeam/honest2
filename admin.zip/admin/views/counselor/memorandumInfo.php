<!-- content start -->
<div class="admin-content">
	<div class="am-cf am-padding">
		<div class="am-fl am-cf"><strong class="am-text-primary am-text-lg">咨询师用户管理</strong> / <small>用户详情</small></div>
	</div>
	<hr>


	<div id="container" class="clearfix">
		<div class="am-g am-intro-bd">
			<div class="am-intro-right am-u-sm-12">
				<section class="am-panel am-panel-default">
					<header class="am-panel-hd">
						<h3 class="am-panel-title">个人资料</h3>
					</header>
					<div class="am-panel-bd am-cf">
						<div class="am-u-sm-6 am-u-md-4">
							<img class="userimg2" src="assets/img/Home_01_02.png" alt="用户头像">
						</div>
						<div class="am-u-sm-6 am-u-md-4">
							<p>咨询师：Dante</p>
							<p>备忘标题：与客户对接项目</p>
							<p>创建时间：2016-05-12</p>
						</div>
						<div class="am-u-sm-6 am-u-md-4">
						</div>
						
					</div>
				</section>
				<section class="am-panel am-panel-default">
					<header class="am-panel-hd">
						<h3 class="am-panel-title">备忘详情</h3>
					</header>
					<div class="am-panel-bd">
						<p></p>
						<p></p>
					</div>
				</section>
				
			</div>
		</div>
		
	</div>

</div>