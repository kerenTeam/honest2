</div>

<a href="#" class="am-show-sm-only admin-menu" data-am-offcanvas="{target: '#admin-offcanvas'}">
  <span class="am-icon-btn am-icon-th-list"></span>
</a>

<footer>
  <hr>
  <p class="am-text-center">© 2014 - 2016 Honest, safe.</p>
</footer>

<!--[if lt IE 9]>
<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="assets/js/amazeui.ie8polyfill.min.js"></script>
<![endif]-->

<!--[if (gte IE 9)|!(IE)]><!-->
<!-- <script src="assets/js/jquery.min.js"></script> -->
<!--<![endif]-->
<script src="assets/js/amazeui.min.js"></script>
<script src="assets/js/jPages.js"></script>
<script src="assets/js/imgup.js"></script>
<script src="assets/js/ga.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>