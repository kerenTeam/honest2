<div class="admin-content">
	<div class="am-cf am-padding">
      <div class="am-fl am-cf"><strong class="am-text-primary am-text-lg">自定义菜单</strong><small></small></div>
    </div>


    <div class="am-padding">
    	<p class="am-text-danger">*请注意：微信菜单长度请不要超过5个汉字</p>
    	
    	<ul>
    		<li>
    			<p>一级菜单</p>
                <form class="am-form noblock" accept-charset="utf-8">
                <i class="am-icon-bars"></i>
                 <input type="hidden" name="id" value="1">
                    <input type="text" name="name" value="安全咨询" placeholder="安全咨询">
                    <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                    <lable>值：</lable>
                    <input type="text" name="key" class="form-control" value="">
                    <a onclick="doaction(this)" class="am-btn am-btn-primary">确认信息</a>
                </form>



                    <ul class="mar-left">
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                    </ul>

    		</li>
    		<li>
    			<p>一级菜单</p>
                <form class="am-form noblock" accept-charset="utf-8">
                <i class="am-icon-bars"></i>
                 <input type="hidden" name="id" value="1">
                    <input type="text" name="name" value="安全咨询" placeholder="安全咨询">
                    <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                    <lable>值：</lable>
                    <input type="text" name="key" class="form-control" value="">
                    <a onclick="doaction(this)" class="am-btn am-btn-primary">确认信息</a>
                </form>



                    <ul class="mar-left">
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                    </ul>

    		</li>
    		<li>
    			<p>一级菜单</p>
                <form class="am-form noblock" accept-charset="utf-8">
                <i class="am-icon-bars"></i>
                 <input type="hidden" name="id" value="1">
                    <input type="text" name="name" value="安全咨询" placeholder="安全咨询">
                    <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                    <lable>值：</lable>
                    <input type="text" name="key" class="form-control" value="">
                    <a onclick="doaction(this)" class="am-btn am-btn-primary">确认信息</a>
                </form>



                    <ul class="mar-left">
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                        <li> 
                        <form class="am-form noblock" accept-charset="utf-8">
                            <i class="am-icon-sort-desc"></i>
                            <input type="hidden" name="id" value="4">
                            <input type="text" class="form-control" name="name" value="我的帐号" placeholder="子菜单名称">
                     <select name="type" id="inputType" class="form-control" style="width:90px;" required="required">
                        <option value="click">点击</option>
                        <option value="view">连接</option>
                    </select>
                            <lable>值：</lable>
                            <input type="text" name="key" class="form-control" placeholder="http://www.abc.com" style="width:300px !important">
                        <a onclick="doaction(this)" class="am-btn am-btn-primary ">确认信息</a>
                        </form>
                        </li>
                    </ul>

    		</li>
    	</ul>



    </div>

</div>