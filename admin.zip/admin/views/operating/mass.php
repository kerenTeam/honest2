<div class="admin-content">
	<div class="am-cf am-padding">
      <div class="am-fl am-cf"><strong class="am-text-primary am-text-lg">消息群发</strong><small></small></div>
    </div>


<form class="am-form">

	<div class="am-g am-padding">
		<label>
			群发对象
		</label>
		<select style="width:190px;display: inline-block;">
			<option value="1">微信会员</option>
		</select>
		<label>
			性别
		</label>
		<select style="width:84px;display: inline-block;">
			<option value="1">全部</option>
		</select>
		<label>
			标签
		</label>
		<select style="width:84px;display: inline-block;">
			<option value="1">全部</option>
			<option value="1">科技</option>
			<option value="1">法律</option>
		</select>
	</div>
	
	<div class="am-g am-padding-bottom-lg">
		<div class="am-u-sm-12 am-u-md-12 am-margin-top">
			<div class="am-btn-toolbar">
				<div class="am-btn-group am-btn-group-xs">
					<a class="am-btn am-btn-default" href="<?=site_url('operating/material');?>"><span class="am-icon-plus"></span> 新增</a>
				</div>
			</div>
		</div>
	</div>


	<div class="am-g">
		<div class="am-u-sm-3 border">
			<label class="am-checkbox am-secondary massInput">
				<input type="radio" value="" name="massSc" data-am-ucheck>
			</label>
			<div class="am-thumbnail minpan">
			     <img class="gdImg" src="assets/img/05-16-21-28-59.jpg" alt=""/>
			     <div class="am-thumbnail-caption">
			     <p class="am-text-center">3146598798asdfas</p>
			     </div>
			</div>
		</div>
		<div class="am-u-sm-3 am-border-radius border">
			<label class="am-checkbox am-secondary massInput">
				<input type="radio" value="" name="massSc" data-am-ucheck>
			</label>
			<div class="am-thumbnail minpan">
			     <img class="gdImg" src="assets/img/05-16-21-28-59.jpg" alt=""/>
			     <div class="am-thumbnail-caption">
			     <p class="am-text-center">3146598798asdfas</p>
			     </div>
			</div>
		</div>
		<div class="am-u-sm-3 am-border-radius border">
			<label class="am-checkbox am-secondary massInput">
				<input type="radio" value="" name="massSc" data-am-ucheck>
			</label>
			<div class="am-thumbnail minpan">
			     <img class="gdImg" src="assets/img/05-16-21-28-59.jpg" alt=""/>
			     <div class="am-thumbnail-caption">
			     <p class="am-text-center">3146598798asdfas</p>
			     </div>
			</div>
		</div>
	</div>
	<div class="am-cf am-padding">
		<div class="am-fr">
			<button type="submit" class="am-btn am-btn-primary">提交</button>
		</div>
	</div>







</form>







</div>