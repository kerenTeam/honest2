

<div class="admin-content">
<iframe src="<?=site_url('other/visitInfo');?>" style="width: 100%; min-height: 1100px;"></iframe>
</div>