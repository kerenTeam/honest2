<div class="admin-content">
	<div class="am-cf am-padding">
		<div class="am-fl am-cf"><strong class="am-text-primary am-text-lg">权限管理</strong><small></small></div>
	</div>





<!-- 列表 -->
		<div class="am-g">
			<div class="am-u-sm-12">
				<table class="am-table am-table-striped am-table-hover am-main am-table-centered am-table-bordered">
					<thead>
						<tr>
							<th>序号</th><th class="table-title">用户名</th><th class="table-title">操作内容</th><th class="table-date am-hide-sm-only">时间</th><th class="table-date am-hide-sm-only">操作sql</th>
						</tr>
					</thead>
					<tbody id="movies">
						<tr>
							<td>1</td>
							<td>admin</td>
							<td>删除用户！</td>
							<td>2016-05-21 00:50:54</td>
							<td>DELETE FROM bk_admin WHERE id='24';</td>
						</tr>
					</tbody>
				</table>
        <div class="am-cf">
            共 3 条记录
            <div class="am-fr">
              <div class="holder"><a class="jp-previous jp-disabled">上一页</a><a class="jp-current">1</a><span class="jp-hidden">...</span><a href="#" class="">2</a><a href="#" class="">3</a><a href="#" class="">4</a><a href="#" class="">5</a><a href="#" class="jp-hidden">6</a><span>...</span><a>7</a><a class="jp-next">下一页</a></div>
            </div>
          </div>
			</div>
		</div>







</div>